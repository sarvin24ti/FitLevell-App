package com.example.sarvin_tia

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.sarvin_tia.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
//        val tombolLogin: Button = findViewById(R.id.buttonn_Login)
//        val username: EditText = findViewById(R.id.edtuser)
//        val Password: EditText = findViewById(R.id.edtPassword)

    binding.buttonnLogin.setOnClickListener {
        val user = binding.edtuser.text
        val password = binding.edtPassword.text

        Log.d("output" , "username : $user password: $password")
        Toast.makeText(this,"username: $user password: $password", Toast.LENGTH_LONG).show()

    }
    }
}
